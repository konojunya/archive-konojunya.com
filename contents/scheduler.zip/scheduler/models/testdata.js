var mongoose = require('mongoose');
var Schema = mongoose.Schema;

var test = new Schema({
	data: Object
});

module.exports = mongoose.model('test', test);