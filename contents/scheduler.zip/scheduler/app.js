var express = require('express'),
    app = express(),
    ECT = require('ect'),
    ectRenderer = ECT({ watch: true, root: __dirname + '/views', ext: '.ect' }),
    mongoose = require('mongoose'),
    port = process.env.PORT || 1337,
    bodyParser = require('body-parser'),
    cookieParser = require('cookie-parser'),
    session = require('express-session'),
    User = require("./models/users"),
    Schedules = require("./models/schedules"),
    COOKIE_SECRET = "o1u23hpuihw42309hfpo2u13r",
    server = require('http').Server(app),
    uuid = require('node-uuid'),
    Test = require("./models/testdata");

mongoose.connect("mongodb://localhost/schedules");

var uuidv4 = uuid.v4().split('-').join('');

app.use(bodyParser.urlencoded({ extended: true }));
app.use(bodyParser.json());
app.use(cookieParser(COOKIE_SECRET));
app.use(session({
  secret: COOKIE_SECRET,
  resave: false,
  saveUninitialized: false
}));
app.use(express.static(__dirname + '/public'));
app.set('view engine', 'ect');
app.engine('ect', ectRenderer.render);

// route
app.get("/",function(req,res){
  if(req.cookies.token){
    res.redirect("/schedules");
  }else{
    res.render("index.ect");
  }
});

app.post("/login",function(req,res){
  var id = req.body.id;
  User.find({id: id},function(err,user){
    if(user != ""){
      res.cookie("token",uuidv4,{maxAge: 6000,httpOnly: true});
      res.redirect("/");
    }else{
      res.redirect("/signup");
    }
  });
});
app.get("/login",function(req,res){
  if(req.cookies.token){
    res.redirect("/");
  }else{
    res.redirect("/signup");
  }
});

app.get("/signup",function(req,res){
  res.render("signup.ect");
});

app.post("/signup",function(req,res){
  var id = req.body.id;
  var password = req.body.password;
  if(id == "" || password == "" || id == password){
    res.render("signup.ect");
  }
  // var department = req.body.department;
  User.find({id: id},function(err,users){
    console.log("log: ",id);
    if(users == ""){
      var user = new User();
      user.id = id;
      user.password = password;
      // user.department = department;
      user.save(function(err){
        if(err)
          res.send(err);
        console.log(err);
        res.render("signup-schedule.ect");
      });
    }else{
      res.render("signup.ect")
    }
  });
});

app.post("/addSchedules",function(req,res){
  console.log("data",req.body.data)
  if(req.body.data){
    var data = req.body.data;
    console.log(data)
    var testdata = new Test();
    testdata.data = data;
    testdata.save(function(err){
      if(err)
        res.send(err);
      res.cookie("token",uuidv4,{maxAge:10000,httpOnly:true});
      res.redirect("/");
    });
  }else{
    res.render("signup-schedule.ect");
  }
});

app.get("/schedules",function(req,res){
  if(req.cookies.token)
    res.send("一覧ページ");
  res.redirect("/");
});

server.listen(port);
console.log("listening on port: "+port);